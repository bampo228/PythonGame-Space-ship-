import pygame
import random

ASTEROID_RADIUS = 15
ASTEROID_SPEED = 5
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
RED = (255, 0, 0)

class Asteroid:
    def __init__(self):
        self.rect = pygame.Rect(random.randint(0, SCREEN_WIDTH - ASTEROID_RADIUS * 2), random.randint(-100, -40), ASTEROID_RADIUS * 2, ASTEROID_RADIUS * 2)
        self.speed = ASTEROID_SPEED

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > SCREEN_HEIGHT:
            self.rect.x = random.randint(0, SCREEN_WIDTH - ASTEROID_RADIUS * 2)
            self.rect.y = random.randint(-100, -40)

    def draw(self, screen):
        pygame.draw.circle(screen, RED, self.rect.center, ASTEROID_RADIUS)
