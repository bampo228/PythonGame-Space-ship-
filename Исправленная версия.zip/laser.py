import pygame

LASER_WIDTH = 5
LASER_HEIGHT = 20
LASER_SPEED = 10
WHITE = (255, 255, 255)

laser_image = pygame.Surface((LASER_WIDTH, LASER_HEIGHT))
laser_image.fill(WHITE)

class Laser:
    def __init__(self, x, y):
        self.image = laser_image
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y

    def update(self):
        self.rect.y -= LASER_SPEED

    def draw(self, screen):
        screen.blit(self.image, self.rect)
