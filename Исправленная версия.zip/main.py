import pygame
import time
import sqlite3
from spaceship import Spaceship
from laser import Laser
from asteroid import Asteroid
from super_asteroid import SuperAsteroid
from score_manager import ScoreManager, create_scores_table
from utils import show_start_screen, show_game_over_screen, show_game_win_screen, show_input_screen, draw_stars

pygame.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (15, 255, 15)
YELLOW = (255, 255, 0)
BLUE = (0, 0, 255)
PURPLE = (128, 0, 128)
SPACESHIP_WIDTH = 30
SPACESHIP_HEIGHT = 30
ASTEROID_RADIUS = 15
SUPER_ASTEROID_RADIUS = 20
LASER_WIDTH = 5
LASER_HEIGHT = 20
LASER_SPEED = 10
ASTEROID_SPEED = 5
LIVES = 3
GAME_DURATION = 40
SUPER_ASTEROID_INTERVAL = 10
SPEED_BOOST_DURATION = 5
NUM_STARS = 100

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Space Shooter")

laser_image = pygame.Surface((LASER_WIDTH, LASER_HEIGHT))
laser_image.fill(WHITE)

def game_loop(player_name):
    global lives
    lives = LIVES
    destroyed_asteroids = 0
    start_time = time.time()
    last_super_asteroid_time = time.time()
    speed_boost_end_time = 0

    spaceship = Spaceship()
    lasers = []
    asteroids = [Asteroid() for _ in range(5)]
    super_asteroids = []

    last_shot_time = time.time()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        spaceship.update()

        current_time = time.time()
        elapsed_time = current_time - start_time
        if elapsed_time >= GAME_DURATION:
            running = False
            score_manager.add_score(player_name, destroyed_asteroids)
            top_scores = score_manager.get_top_scores(5)
            if show_game_win_screen(destroyed_asteroids, top_scores):
                game_loop(player_name)
            else:
                pygame.quit()
                exit()

        if current_time - last_shot_time >= spaceship.laser_interval:
            lasers.append(Laser(spaceship.rect.centerx, spaceship.rect.top))
            last_shot_time = current_time

        if (current_time - last_super_asteroid_time) >= SUPER_ASTEROID_INTERVAL:
            super_asteroids.append(SuperAsteroid())
            last_super_asteroid_time = current_time

        for laser in lasers:
            laser.update()
            if laser.rect.bottom < 0:
                lasers.remove(laser)

        for asteroid in asteroids:
            asteroid.update()
            for laser in lasers:
                if laser.rect.colliderect(asteroid.rect):
                    lasers.remove(laser)
                    asteroids.remove(asteroid)
                    asteroids.append(Asteroid())
                    destroyed_asteroids += 1
                    break
            if asteroid.rect.colliderect(spaceship.rect):
                lives -= 1
                asteroids.remove(asteroid)
                asteroids.append(Asteroid())
                if lives <= 0:
                    running = False
                    if show_game_over_screen(destroyed_asteroids):
                        game_loop(player_name)
                    else:
                        pygame.quit()
                        exit()
                    break

        for super_asteroid in super_asteroids:
            super_asteroid.update()
            for laser in lasers:
                if laser.rect.colliderect(super_asteroid.rect):
                    lasers.remove(laser)
                    super_asteroids.remove(super_asteroid)
                    spaceship.laser_interval = 0.33
                    speed_boost_end_time = current_time + SPEED_BOOST_DURATION
                    break
            if super_asteroid.rect.colliderect(spaceship.rect):
                lives -= 1
                super_asteroids.remove(super_asteroid)
                if lives <= 0:
                    running = False
                    if show_game_over_screen(destroyed_asteroids):
                        game_loop(player_name)
                    else:
                        pygame.quit()
                        exit()
                    break

        if current_time >= speed_boost_end_time and speed_boost_end_time != 0:
            spaceship.laser_interval = 1
            speed_boost_end_time = 0

        screen.fill(BLACK)
        draw_stars()
        spaceship.draw()
        for laser in lasers:
            laser.draw()
        for asteroid in asteroids:
            asteroid.draw()
        for super_asteroid in super_asteroids:
            super_asteroid.draw()

        font = pygame.font.Font(None, 36)
        lives_text = font.render(f"Lives: {lives}", True, WHITE)
        screen.blit(lives_text, (10, 10))

        time_left = max(0, int(GAME_DURATION - elapsed_time))
        timer_text = font.render(f"Time: {time_left}", True, WHITE)
        screen.blit(timer_text, (10, 50))

        destroyed_text = font.render(f"Destroyed: {destroyed_asteroids}", True, WHITE)
        screen.blit(destroyed_text, (10, 90))

        pygame.display.flip()
        pygame.time.Clock().tick(60)

    show_start_screen()

create_scores_table()

score_manager = ScoreManager()

player_name = show_input_screen()
show_start_screen()
game_loop(player_name)

pygame.quit()
