import sqlite3

class Score:
    def __init__(self, id, name, score):
        self.id = id
        self.name = name
        self.score = score

class ScoreManager:
    def __init__(self, db_name='scores.db'):
        self.db_name = db_name

    def add_score(self, name, score):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        cursor.execute('INSERT INTO scores (name, score) VALUES (?, ?)', (name, score))
        conn.commit()
        conn.close()

    def get_top_scores(self, limit=5):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT name, MAX(score) as max_score
            FROM scores
            GROUP BY name
            ORDER BY max_score DESC
            LIMIT ?
        ''', (limit,))
        rows = cursor.fetchall()
        conn.close()
        return [Score(None, name, score) for name, score in rows]

def create_scores_table():
    conn = sqlite3.connect('scores.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            score INTEGER NOT NULL
        )
    ''')
    conn.commit()
    conn.close()
