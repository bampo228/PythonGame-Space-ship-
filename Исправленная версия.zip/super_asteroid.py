import pygame
import random

SUPER_ASTEROID_RADIUS = 20
ASTEROID_SPEED = 5
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
YELLOW = (255, 255, 0)

class SuperAsteroid:
    def __init__(self):
        self.rect = pygame.Rect(random.randint(0, SCREEN_WIDTH - SUPER_ASTEROID_RADIUS * 2), random.randint(-100, -40), SUPER_ASTEROID_RADIUS * 2, SUPER_ASTEROID_RADIUS * 2)
        self.speed = ASTEROID_SPEED

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > SCREEN_HEIGHT:
            self.rect.x = random.randint(0, SCREEN_WIDTH - SUPER_ASTEROID_RADIUS * 2)
            self.rect.y = random.randint(-100, -40)

    def draw(self, screen):
        pygame.draw.circle(screen, YELLOW, self.rect.center, SUPER_ASTEROID_RADIUS)
