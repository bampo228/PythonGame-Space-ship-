import pygame
import random

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
PURPLE = (128, 0, 128)
NUM_STARS = 100

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

def draw_stars():
    for _ in range(NUM_STARS):
        x = random.randint(0, SCREEN_WIDTH)
        y = random.randint(0, SCREEN_HEIGHT)
        color = random.choice([WHITE, BLUE, PURPLE])
        pygame.draw.circle(screen, color, (x, y), 2)

def show_start_screen():
    font = pygame.font.Font(None, 74)
    text = font.render("Стартуем!", True, WHITE)
    text_rect = text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 100))

    description_font = pygame.font.Font(None, 24)
    description_text = (
        "Твоя задача уничтожить как можно больше астероидов за 40 секунд. "
        "Управление осуществляется стрелочками. Уничтожение желтых астероидов дает бафф "
        "скорострельности на несколько секунд. Попадание астероида по кораблю снимает одну жизнь, "
        "всего их 3. Будь осторожен и удачи!"
    )
    description_lines = description_text.split(' ')
    description_surface = []
    current_line = ''

    for word in description_lines:
        if description_font.size(current_line + word)[0] < SCREEN_WIDTH - 20:
            current_line += word + ' '
        else:
            description_surface.append(description_font.render(current_line, True, WHITE))
            current_line = word + ' '
    description_surface.append(description_font.render(current_line, True, WHITE))

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if text_rect.collidepoint(event.pos):
                    running = False

        screen.fill(BLACK)
        draw_stars()
        screen.blit(text, text_rect)

        y_offset = SCREEN_HEIGHT // 2
        for line in description_surface:
            screen.blit(line, (10, y_offset))
            y_offset += line.get_height()

        pygame.display.flip()

def show_game_over_screen(score):
    font = pygame.font.Font(None, 74)
    text = font.render("Вы проиграли!", True, WHITE)
    text_rect = text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50))

    score_text = font.render(f"Счет: {score}", True, WHITE)
    score_rect = score_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))

    restart_button = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 + 50, 200, 50)
    quit_button = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 + 120, 200, 50)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if restart_button.collidepoint(event.pos):
                    return True
                if quit_button.collidepoint(event.pos):
                    return False

        screen.fill(BLACK)
        draw_stars()
        screen.blit(text, text_rect)
        screen.blit(score_text, score_rect)
        pygame.draw.rect(screen, GREEN, restart_button)
        pygame.draw.rect(screen, RED, quit_button)

        font = pygame.font.Font(None, 36)
        restart_text = font.render("Рестарт", True, WHITE)
        screen.blit(restart_text, (restart_button.x + 50, restart_button.y + 10))

        quit_text = font.render("Выход", True, WHITE)
        screen.blit(quit_text, (quit_button.x + 50, quit_button.y + 10))

        pygame.display.flip()

def show_game_win_screen(score, top_scores):
    font = pygame.font.Font(None, 74)
    text = font.render("Вы выиграли!", True, WHITE)
    text_rect = text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 150))

    score_text = font.render(f"Счет: {score}", True, WHITE)
    score_rect = score_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 100))

    top_scores_text = font.render("Топ 5 игроков:", True, WHITE)
    top_scores_rect = top_scores_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50))

    restart_button = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 + 150, 200, 50)
    quit_button = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 + 220, 200, 50)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if restart_button.collidepoint(event.pos):
                    return True
                if quit_button.collidepoint(event.pos):
                    return False

        screen.fill(BLACK)
        draw_stars()
        screen.blit(text, text_rect)
        screen.blit(score_text, score_rect)
        screen.blit(top_scores_text, top_scores_rect)

        y_offset = SCREEN_HEIGHT // 2
        for score in top_scores:
            score_text = font.render(f"{score.name}: {score.score}", True, WHITE)
            screen.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, y_offset))
            y_offset += score_text.get_height() + 10

        pygame.draw.rect(screen, GREEN, restart_button)
        pygame.draw.rect(screen, RED, quit_button)

        font = pygame.font.Font(None, 36)
        restart_text = font.render("Рестарт", True, WHITE)
        screen.blit(restart_text, (restart_button.x + 50, restart_button.y + 10))

        quit_text = font.render("Выход", True, WHITE)
        screen.blit(quit_text, (quit_button.x + 50, quit_button.y + 10))

        pygame.display.flip()

def show_input_screen():
    font = pygame.font.Font(None, 36)
    input_box = pygame.Rect(SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT // 2 - 25, 300, 50)
    color_inactive = pygame.Color('lightskyblue3')
    color_active = pygame.Color('dodgerblue2')
    color = color_inactive
    active = False
    text = ''
    done = False

    while not done:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box.collidepoint(event.pos):
                    active = not active
                else:
                    active = False
                color = color_active if active else color_inactive
            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN:
                        done = True
                    elif event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                    else:
                        text += event.unicode

        screen.fill(BLACK)
        draw_stars()

        # Отображение надписи "Введите свой ник"
        prompt_text = font.render("Введите свой ник:", True, WHITE)
        screen.blit(prompt_text, (SCREEN_WIDTH // 2 - prompt_text.get_width() // 2, SCREEN_HEIGHT // 2 - 100))

        txt_surface = font.render(text, True, color)
        width = max(200, txt_surface.get_width() + 10)
        input_box.w = width
        screen.blit(txt_surface, (input_box.x + 5, input_box.y + 5))
        input_box.w = max(200, txt_surface.get_width() + 10)
        pygame.draw.rect(screen, color, input_box, 2)

        pygame.display.flip()

    return text
